import StorySubmitForm from '@/components/story/StorySubmitForm';

export default function StorySharing() {
  return <StorySubmitForm />;
}