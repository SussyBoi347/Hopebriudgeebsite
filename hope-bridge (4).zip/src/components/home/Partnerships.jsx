import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { CheckCircle2, ArrowRight } from 'lucide-react';

const benefits = [
"Culturally responsive mental health workshops for students",
"Professional development for counselors and staff",
"Student-led peer support program implementation",
"Parent education sessions on teen mental health",
"Crisis response planning and support",
"Ongoing consultation and resources"];


export default function Partnerships() {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="partnerships" className="py-24 lg:py-32 bg-gradient-to-br from-blue-900 via-slate-800 to-cyan-900 text-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}>

            <span className="text-cyan-300 font-medium text-sm tracking-wide uppercase">
              For Schools
            </span>
            <h2 className="mt-4 text-3xl sm:text-4xl font-semibold text-white leading-tight">
              Partner with Hope Bridge
            </h2>
            
            <p className="mt-6 text-lg text-blue-100 leading-relaxed">Schools play a critical role in supporting student mental health. Hope Bridge aims to work alongside educators to create environments where every student especially those facing cultural pressures around success feels supported.



            </p>

            <p className="mt-4 text-blue-100 leading-relaxed">



            </p>

            <div className="mt-8">
              <Button
                onClick={scrollToContact}
                className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white px-8 py-6 rounded-full shadow-lg shadow-blue-500/25">

                Discuss Partnership
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </div>
          </motion.div>


        </div>
      </div>
    </section>);

}