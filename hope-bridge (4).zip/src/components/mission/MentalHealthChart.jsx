import React from 'react';
import { PieChart, Pie, Cell, Legend, Tooltip, ResponsiveContainer } from 'recharts';
import { motion } from 'framer-motion';

export default function MentalHealthChart() {
  const data = [
  { name: 'Experience anxiety/depression', value: 45 },
  { name: 'Academic stress', value: 30 },
  { name: 'Identity concerns', value: 15 },
  { name: 'Family pressure', value: 10 }];


  const COLORS = ['#00D9FF', '#0088CC', '#00FFF0', '#0066AA'];

  return null;









































}